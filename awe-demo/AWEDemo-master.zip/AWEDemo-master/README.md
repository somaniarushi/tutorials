# Guess The Word - Intro To iOS Demo for AWE

A simple word guessing game designed to teach fundamential aspects of iOS development. 
